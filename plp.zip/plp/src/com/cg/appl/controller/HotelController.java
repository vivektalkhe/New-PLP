package com.cg.appl.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;


@Controller
@SessionAttributes({"userID","UserRole","roomDetails","dateError","list","errorMsg","roomId","roomIDForRoomUpdate","roomType","fromDate","toDate","noOfRooms","noOfAdults","noOfChildren","hotelIDForUpdate","oprStatus","oprStatusFailed","rooms","deleteException","hotel","updateHotelIDInvalid","list","bookingList","dateErrorForHotelwiseBooking"})
public class HotelController {
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    sdf.setLenient(true);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	private IHotelServices services;
	
	/*@PostConstruct
	public void initialize(){
		ModelAndView model=new ModelAndView();
	}*/
    @Resource(name="hotelService")
	public void setServices(IHotelServices services) {
		this.services = services;
	}
    @RequestMapping("/welcome.do")
    public ModelAndView welcome(){
    	
    	ModelAndView model=new ModelAndView("index");
    	Users user=new Users();
    	model.addObject("user",user);
    	
    	Users user2=new Users();
    	model.addObject("user2",user2);
    	return model;
    	
    }
    @RequestMapping("/test.do")
    public ModelAndView test(){
    	
    	ModelAndView model=new ModelAndView("error");
    try {
		List<BookingDetails> list=services.test();
		model.addObject("msg", list);
	} catch (BookingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    	return model;
    	
    }
/*    @RequestMapping("/showRegisterNewUser.do")
    public ModelAndView getRegisterNewUser(){
    	ModelAndView model=new ModelAndView();
		
    	Users user = new Users();
    	model.addObject("user",user);
    	model.setViewName("Register");
    	
    	return model;
    }
    */
    @RequestMapping("/registerNewUser.do")
    public ModelAndView registerNewUser(@ModelAttribute("user2") Users user2/*,BindingResult result*/){
    	ModelAndView model=new ModelAndView();
		try {
			String uName = services.addUser(user2);
			/*if(result.hasErrors()){
				System.out.println(result.getAllErrors());
				model.addObject("user",user);
				model.setViewName("index");
				return model;
				
			}		*/
			if(uName.equals(user2.getUser_name()))
				{
					model.addObject("oprStatus", "User "+uName+" is Registered to system !!!");					
				}
			else
				{
				    model.addObject("oprStatusFailed", "Unable to register New User "+uName);
				}
			model.setViewName("Register");
		} catch (BookingException e) {
			e.printStackTrace();
		}
    	return model;
    }
    
    @RequestMapping("/authenticate.do")
    public ModelAndView authenticate(@ModelAttribute Users user,HttpServletRequest request, HttpSession session){
    	ModelAndView model=new ModelAndView();
    /*	String role = services.isUserAuthanticate(user, pwd);*/
		
try {
			Users authenticatedUser = services.isUserAuthenticated(user.getUser_name(),user.getPassword());
			
		/*	if (authenticatedUser.getRole().equals("mac")) {
				HttpSession log = request.getSession(true);
				log.setAttribute("logRight", role);
				System.out.println(role);
				nextJspString = "member.jsp";
			}

			else if (authenticatedUser.getRole().equals("admin")) {
				nextJspString = "admin.jsp";
				HttpSession log = request.getSession(true);
				log.setAttribute("logRight", role);
			}
			*/
			if(!authenticatedUser.getUser_id().equals("error"))
			{
				System.out.println("Yes");
										
				//code for starting new session

				session = request.getSession(true);
		
				String UserRole = authenticatedUser.getRole();
				if(UserRole.equals("Customer")||UserRole.equals("HotelEmp")||UserRole.equals("n/a"))
				{
					model.addObject("UserRole",UserRole);
					model.addObject("userID",authenticatedUser.getUser_id());
					//model.addObject("userID",authenticatedUser.getUser_id());
					BookingDetails bookingDetails=new BookingDetails();
					model.addObject("bookingDetails",bookingDetails);
					List<Hotel> hotelList=services.showAllHotel();
					model.addObject("list",hotelList);
					model.setViewName("book");
					//nextJsp = "showCustomerMenu.do";
				}
				else if(UserRole.equals("Admin"))
				{
					model.addObject("UserRole",UserRole);
					model.addObject("userID",authenticatedUser.getUser_id());
					//model.addObject("userID",authenticatedUser.getUser_id());
					//List<Hotel> hotelList = services.showAllHotel();
			 	   // model.addObject("list", hotelList);
			 		model.setViewName("adminMenu");
					//nextJsp = "showAdminMenu.do";
				}
				
			}
			else
			{
				System.out.println("No");
				
				String message = "Wrong Credentials Entered !!!";
				
				model.addObject("errorMsg",message);
				//request.setAttribute("errorMsg", message);
				//ctx.log("error Message : "+message);
				model.setViewName("index");
				//nextJsp = "/index.jsp";
			}
			
		} catch (BookingException e) {
			
			/*dispatch = request.getRequestDispatcher("error");
			dispatch.forward(request, response);*/
			model.setViewName("index");
			//nextJsp = "/index.jsp";
			System.out.println(e);
			//ctx.log(e.getMessage());
			String message = "User Name does not exist !!!";
			model.addObject("errorMsg",message);
			//request.setAttribute("errorMsg", message);
		}
    	return model;
    }
    
    @RequestMapping("/showAdminMenu.do")
    public ModelAndView showAdminMenu(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	
    	String UserRole = (String) session.getAttribute("UserRole");
		
		if(UserRole==null)
		{
			model.setViewName("error");
			return model;
		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		List<Hotel> hotelList = services.showAllHotel();
 	    model.addObject("list", hotelList);
 		model.setViewName("adminMenu");
 		//nextJsp = "/adminMenu.jsp";
    	return model;
    }
    
    @RequestMapping("/showAddRoom.do")
    public ModelAndView showAddRoom(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
	String UserRole = (String) session.getAttribute("UserRole");
		RoomDetails room = new RoomDetails();

		if(UserRole==null)
		{
			model.setViewName("error");
			return model;
		}
		
		model.addObject("room", room);
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("show add room user Id : "+user_id);
 		
 		List<Hotel> list = services.showAllHotel();
 		model.addObject("list", list);
 		model.setViewName("addRoom");
 		//nextJsp = "/addRoom.jsp";
    	return model;
    }
    
    @RequestMapping("/addRoom.do")
    public ModelAndView addRoom(@ModelAttribute ("room") @Valid RoomDetails room,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
        String UserRole = (String) session.getAttribute("UserRole");
		
		if(UserRole==null)
		{
			model.setViewName("error");
			return model;
		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("add room user Id : "+user_id);
 		
 		//RoomDetails room = new RoomDetails();
 		room.setAvailability(1);
 		//room.setHotel_id(hotelName);
 		/*room.setPer_night_rate(room.getPer_night_rate());
 		room.setRoom_no((room.getRoom_no()));
 		room.setRoom_type(room.getRoom_type());*/
 		
 		String roomID = services.addRoom(room);
 		
 		model.addObject("oprStatus","Room: "+roomID+" is added successfully to Hotel "+services.GetHotelName(room.getHotel().getHotel_name()));
 		model.setViewName("adminMenu");
 		//nextJsp = "/adminMenu.jsp";
    	return model;
    }
    
    @RequestMapping("/showUpdateRoom.do")
    public ModelAndView showUpdateRoom(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
	    String UserRole = (String) session.getAttribute("UserRole");
		
		if(UserRole==null)
		{
			model.setViewName("error");
			return model;
		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("roomDetailsForUpdate user Id : "+user_id);
 		model.setViewName("updateRoom");
 		//nextJsp = "/updateRoom.jsp";
    	return model;
    }
    
    @RequestMapping("/showNPopulateUpdateRoom.do")
    public ModelAndView showNPopulateUpdateRoom(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
	    String UserRole = (String) session.getAttribute("UserRole");
		
		if(UserRole==null)
		{
			model.setViewName("error");
			return model;
		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("show update room user Id : "+user_id);
 		
 		String hotelID = request.getParameter("hotelid");
 		String roomID = request.getParameter("roomID");
 		
 		model.addObject("hotelIDForUpdate",hotelID);
 		//model.addObject("hotelIDForUpdate", hotelId);
 		System.out.println("hksdffguyksdfbuhk");
 		RoomDetails room = services.showRoom(hotelID, roomID);
 		System.out.println(room);
 		if(room.getRoom_type()==null)
 		{
 			model.addObject("oprStatusUpdateRoom","Room id/Hotel id does not exist ");
 			model.setViewName("updateRoom");
 			//nextJsp = "/updateRoom.jsp";
 		}
 		else
 		{ 
 			model.addObject("roomDetails",room);
 			model.addObject("roomID", roomID);
 			model.addObject("roomIDForRoomUpdate", roomID);
 			model.addObject("roomType",room.getRoom_type());
 			/*model.addObject("roomDetails", room);
 			model.addObject("roomID", roomID);
 			model.addObject("roomIDForRoomUpdate", roomID);
 			model.addObject("roomType",room.getRoom_type());*/
 			model.setViewName("updatePopulateRoom");
 			//nextJsp = "/updatePopulateRoom.jsp";
 		}
 		
    	return model;
    }
    
    @RequestMapping("/updateRoom.do")
    public ModelAndView updateRoom(@ModelAttribute ("roomDetails") RoomDetails room,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("update room user Id : "+user_id);
 		
 		//RoomDetails room = new RoomDetails();
 		room.setAvailability(1);
 		//room.setHotel_id(request.getParameter("hotelName"));
 		//room.setPer_night_rate(Integer.parseInt(request.getParameter("roomPrice")));
 		//room.setRoom_no((request.getParameter("roomNo")));
 		
 		
 		
 		if(request.getParameter("room_type").equals("blank"))
 		{
 			room.setRoom_type(request.getParameter("roomTypeOld"));
 		}
 		else
 		{
 			room.setRoom_type(request.getParameter("room_type"));
 		}
 
 		System.out.println(room.getRoom_type());
 		
 		room.setRoom_id(session.getAttribute("roomIDForRoomUpdate").toString());
 		
 		String hotelID = request.getParameter("hotelID");
 		
 		boolean isUpdated = services.updateRoom(room, hotelID);
 		
 		if(isUpdated)
 		{
 			model.addObject("oprStatus","Room: "+room.getRoom_id()+" is updated successfully for Hotel "+services.GetHotelName(hotelID));
 		}
 		else
 		{
 			model.addObject("oprStatusFailed","Room: "+room.getRoom_id()+" is Unable to update for Hotel "+services.GetHotelName(hotelID));
 		}
 		model.setViewName("adminMenu");
 		//nextJsp = "/adminMenu.jsp";
    	return model;
    }
    
    @RequestMapping("/showDeleteRoom.do")
    public ModelAndView showDeleteRoom(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
        String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
  		
  		Hotel hotel = new Hotel();
  		model.addObject("hotel", hotel);
  		
  		List<Hotel> list = services.showAllHotel();
 		model.addObject("list", list);
  		
  		RoomDetails room = new RoomDetails();
  		model.addObject("room", room);
  		
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("show Delete room user Id : "+user_id);
 		model.setViewName("deleteRoom");
 		//nextJsp = "/deleteRoom.jsp";
    	return model;
    }
    
    @RequestMapping("/deleteRoom.do")
    //##modelAttribute need to be added
    public ModelAndView deleteRoom(@ModelAttribute ("room") RoomDetails room,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
 		//String hotelID = hotelName;
 		String roomID = room.getRoom_id(); 		
 		System.out.println("roonID " +room.getRoom_id());

 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("delete room user Id : "+user_id);
 			 		
 		boolean isDeleted = services.deleterooms(room.getRoom_id());
 		
 		if(isDeleted)
 		{
 			model.addObject("oprStatus", "Room "+room.getRoom_id()+"is Deleted successfully from Hotel ");
 			model.setViewName("adminMenu");
 			//nextJsp = "/adminMenu.jsp";
 		}
 		else
 		{
 			model.addObject("deleteException","Invalid Room ID : "+room.getRoom_id());
 			model.setViewName("deleteRoom");
 			//nextJsp = "/deleteRoom.jsp";
 		}
    	return model;
    }
    
    @RequestMapping("/showAddHotel.do")
    public ModelAndView showAddHotel(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("addHotel");
 		Hotel hotel=new Hotel();
 		model.addObject("hotel",hotel);
 		//nextJsp = "/addHotel.jsp";
    	return model;
    }
    
    @RequestMapping("/addHotel.do")
    public ModelAndView addHotel(@ModelAttribute Hotel hotel,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();		
		HttpSession session = request.getSession(false);
		  String UserRole = (String) session.getAttribute("UserRole");
			
			if(UserRole==null)
			{
				model.setViewName("error");
				return model;
			}
		/*String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
		String hotelName =  request.getParameter("hotelName");
		hotel.setHotel_name(hotelName);
		String city = request.getParameter("hotelCity");
		hotel.setCity(city);
		String address = request.getParameter("address");
		hotel.setAddress(address);
		String desc = request.getParameter("desc");
		hotel.setDescription(desc);
		int price =Integer.parseInt(request.getParameter("price"));
		hotel.setAvg_rate_per_night(price);
		String contact1 = request.getParameter("phno");
		hotel.setPhone_no1(contact1);
		String contact2 = request.getParameter("phno2");
		hotel.setPhone_no2(contact2);
		int rating =Integer.parseInt(request.getParameter("rate"));
		hotel.setRating(rating);
		String email =request.getParameter("email");
		hotel.setEmail(email);
		String fax =request.getParameter("fax");
		hotel.setFax(fax);*/
						
		String hotelID = services.AddHotel(hotel);
		if(hotelID!=null)
		{
			System.out.println("hotel added !!!");
			model.addObject("hotel", hotel);
		}
		else
		{
			String message = "Unable to add new hotel !!!";
			model.addObject("errorMsg", message);
			//ctx.log("error Message : "+message);
			model.setViewName("addHotel");
			//nextJsp = "/addHotel.jsp";
		}
    	return model;
    }
    
    @RequestMapping("/showUpdateHotel.do")
    public ModelAndView showUpdateHotel(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
  		
  		Hotel hotel = new Hotel();
  		model.addObject("hotel", hotel);
  		
  		Hotel hotel2 = new Hotel();
  		model.addObject("hotel2", hotel2);
  		
 		model.setViewName("updateHotel");
    	//nextJsp = "/updateHotel.jsp";
    	return model;
    }
    
    @RequestMapping("/populateUpdateHotel.do")
    public ModelAndView populateUpdateHotel(@ModelAttribute ("hotel") Hotel hotel,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
 		//getting hotel id from form
 		//String hotelID = request.getParameter("hotelID");
 		//getting hotel details from dao
  		Hotel hotel2 = new Hotel();
 		
 		hotel2 = services.getHotel(hotel.getHotel_id());
 		
 		if(hotel2==null)
 		{
 			model.addObject("updateHotelIDInvalid", "Invalid Hotel ID !!!");
 			model.setViewName("updateHotel");
 			
/* 			nextJsp = "/updateHotel.jsp";
 			dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
 		else
 		{
 			
 			model.addObject("hotel2", hotel2);
 			//setting attribute of session for populating form
 			model.setViewName("updateHotel");
	 		//nextJsp="/updateHotel.jsp";
 		}
    	return model;
    }
    
    @RequestMapping("/updateHotel.do")
    public ModelAndView updateHotel(@ModelAttribute("hotel2") Hotel hotel,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	System.out.println("In Update Hotel.do");
 		HttpSession session = request.getSession(false);
 		  String UserRole = (String) session.getAttribute("UserRole");
 			
 			if(UserRole==null)
 			{
 				model.setViewName("error");
 				return model;
 			}
 		//Hotel hotel = new Hotel();
 	/*	String hotelID = request.getParameter("hotelID2").toString();
 		hotel.setHotel_id(hotelID);
 		String hotelName = request.getParameter("updateHotelName").toString();
 		hotel.setHotel_name(hotelName);
 		String description = request.getParameter("description").toString();
 		hotel.setDescription(description);
 		int price = Integer.parseInt(request.getParameter("price"));
 		hotel.setAvg_rate_per_night(price);
 		String phno1 = request.getParameter("phno1").toString();
 		hotel.setPhone_no1(phno1);
 		String phno2 = request.getParameter("phno2").toString();
 		hotel.setPhone_no2(phno2);
 		int rating = Integer.parseInt(request.getParameter("rating"));
 		hotel.setRating(rating);
 		String email = request.getParameter("email").toString();
 		hotel.setEmail(email);
 		String fax = request.getParameter("fax").toString();
 		hotel.setFax(fax);*/
 		
 		boolean isUpdated = services.updateHotel(hotel);
 		System.out.println(isUpdated);
 		if(isUpdated)
 		{
 			model.setViewName("adminMenu");
 			//nextJsp="/adminMenu.jsp";
 		}
 		else
 		{		 		
 			model.setViewName("adminMenu");
 			//nextJsp="/updateHotel.jsp";
 			String message = "Unable to update Hotel !!!";
 			model.addObject("errorMsg", message);
 		}
    	return model;
    }
    
    @RequestMapping("/showDelete.do")
    public ModelAndView showDelete(HttpServletRequest request){
    	ModelAndView model=new ModelAndView("deleteHotel");
    	Hotel hotel = new Hotel();
    	model.addObject("hotel",hotel);
    	System.out.println("In showDelete.do");
		return model;
    }
    
    @RequestMapping("/delete.do")
    public ModelAndView delete(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	System.out.println("In delete.do");
	 	
	 	HttpSession session = request.getSession(false);
	 	String UserRole = (String) session.getAttribute("UserRole");
			
			if(UserRole==null)
			{
				model.setViewName("error");
				return model;
			}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("deleteHotel");
		//nextJsp = "/deleteHotel.jsp";
    	return model;
    }
    
    @RequestMapping("/deleteHotel.do")
    public ModelAndView deleteHotel(@ModelAttribute Hotel hotel,HttpServletRequest request) throws BookingException{
    	System.out.println("1");
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
    	 System.out.println("In deleteHotel.do");
		 //String hotelId=request.getParameter("hotelId");
		 boolean flag=services.deleteHotel(hotel.getHotel_id());
		 System.out.println("In deleteHotel.do  2");
		 if(flag)
		 {
			 System.out.println("Deleted Hotel Successfully");
			 //nextJsp="/deleteHotel.jsp";
		 }
		 else
		 {
			 System.out.println("Hotel Not Deleted");
			 model.addObject("errorMsg","Unable To delete");
			
			 //nextJsp="/deleteHotel.jsp";
		 }		
		 model.setViewName("deleteHotel");
    	return model;
    }
    
    @RequestMapping("/showReportsMenu.do")
    public ModelAndView showReportsMenu(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("reportsMenu");
 		//nextJsp = "/reportsMenu.jsp";
    	return model;
    }
    
    
    @RequestMapping("/showHotels.do")
    public ModelAndView showHotels(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		
 		List<Hotel> hotelList = services.showAllHotel();
 		model.addObject("list", hotelList);
 		model.setViewName("HotelListReport");
 		//nextJsp = "/HotelListReport.jsp";
    	return model;
    }
    
    @RequestMapping("/getHotelIDForReport.do")
    public ModelAndView getHotelIDForReport(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();

 		HttpSession session = request.getSession(false);
 		  String UserRole = (String) session.getAttribute("UserRole");
 	  		
 	  		if(UserRole==null)
 	  		{
 	  			model.setViewName("error");
 	  			return model;
 	  		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("hotelIDForReport");	 		
 		//nextJsp = "/hotelIDForReport.jsp";
    	return model;
    }
    
    @RequestMapping("/showHotelwiseBooking.do")
    public ModelAndView showHotelwiseBooking(@RequestParam String hotelID,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);		 		

 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
 		
 		for(BookingDetails index : bookingList)
 		{
 			index.setUser(services.getUserDetailsForReport(index.getUser().getUser_id()));
 			//Will be changed later
 		}
 		if(bookingList.isEmpty())
 		{
 			model.addObject("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
 			model.setViewName("acceptHotelIdForReport");	
 			/*nextJsp = "/acceptHotelIdForReport.jsp";
 			dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
 		else
 		{
 			model.addObject("bookingList", bookingList);		 
 			model.setViewName("BookingListReport");	
 	/*		nextJsp = "/BookingListReport.jsp";
	 		dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);	 		*/	
 		}
    	return model;
    }
    
    @RequestMapping("/getHotelIDForGuestListReport.do")
    public ModelAndView getHotelIDForGuestListReport(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("acceptHotelIdForReport"); 		
 		//nextJsp = "/acceptHotelIdForReport.jsp";
    	return model;
    }
    
    @RequestMapping("/showHotelwiseUsers.do")
    public ModelAndView showHotelwiseUsers(@RequestParam String hotelID,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 				 		
 		//String hotelID = request.getParameter("hid");
 		
 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
 		
 		for(BookingDetails index : bookingList)
 		{
 			index.setUser(services.getUserDetailsForReport(index.getUser().getUser_id()));
 			//Will be changed later
 		}
 		
 		if(bookingList.isEmpty())
 		{
 			model.addObject("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
 			model.setViewName("acceptHotelIdForReport");
 			/*nextJsp = "/acceptHotelIdForReport.jsp";
 			dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
 		else
 		{
 		
	 		model.addObject("bookingList", bookingList);	
	 		model.setViewName("GuestListReport");
	 	/*	nextJsp = "/GuestListReport.jsp";
	 		dispatch = request.getRequestDispatcher(nextJsp);
			dispatch.forward(request,response);*/
 		}
    	return model;
    }
    
    @RequestMapping("/getDatesForReport.do")
    public ModelAndView getDatesForReport(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		model.setViewName("specifiedDateReport");	 		
 		//nextJsp = "/specifiedDateReport.jsp";
    	return model;
    }
    
    @RequestMapping("/showDatewiseBooking.do")
    public ModelAndView showDatewiseBooking(@RequestParam("hotelid") String hotelID,@RequestParam("from") Date datefrom,@RequestParam("to") Date dateto ,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 	/*			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date datefrom = sdf.parse(request.getParameter("from"));
					Date dateto = sdf.parse(request.getParameter("to"));*/
					 Date sysdate = new Date();
		
					if (dateto.before(datefrom)) {
					    System.out.println("Date1 is before Date2");
					    model.addObject("dateErrorForDateReport","check-in date must be before check-out Date");
					   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);*/
					} else
						if (datefrom.equals(dateto)) {
					    System.out.println("Date1 is equal to Date2");
					    model.addObject("dateErrorForDateReport","check-in date must be different from check-out Date");
					   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);*/
					}
					else
								if (dateto.before(sysdate)||datefrom.before(sysdate)) {
							    System.out.println("Date1 is equal to Date2");
							    model.addObject("dateErrorForDateReport","check-in /check-out date cannot be before today");
							   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
								dispatch.forward(request,response);*/
					}else 
								if (dateto.after(datefrom)) {
							    System.out.println("Date1 is after Date2");
							    java.sql.Date fDate=new java.sql.Date(datefrom.getTime());
							    java.sql.Date tDate=new java.sql.Date(dateto.getTime());
							    List<BookingDetails> bookingList = services.viewBookingDatewise(fDate, tDate);	 		
						 		
							    if(bookingList.isEmpty())
							    {
							    	model.addObject("dateErrorForDateReport","Hotel ID does not exist !!!");
							    	model.setViewName("specifiedDateReport");
								   /* dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
									dispatch.forward(request,response);*/
							    }else
							    {
							    
							 		model.addObject("bookingList",bookingList);
							 		model.setViewName("dateReport");
							 	/*	nextJsp="/dateReport.jsp";
							 		
								    dispatch = request.getRequestDispatcher(nextJsp);
									dispatch.forward(request,response);*/
							    }
							}
    	return model;
    }
    
    @RequestMapping("/showCustomerMenu.do")
    public ModelAndView showCustomerMenu(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println("user Id : "+user_id);
 		
 		BookingDetails book = new BookingDetails();
 		model.addObject("book",book);
 		
 		List<Hotel> list = services.showAllHotel();
 		model.addObject("list", list);
 		
 		System.out.println(list);
 		model.setViewName("book");
 		//nextJsp = "/book.jsp";
    	return model;
    }
    
    @RequestMapping("/showBookingStatus.do")
    public ModelAndView showBookingStatus(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
  	  String UserRole = (String) session.getAttribute("UserRole");
  		
  		if(UserRole==null)
  		{
  			model.setViewName("error");
  			return model;
  		}
    	return model;
    }
    
    @RequestMapping("/booking.do")
    public ModelAndView booking(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
	 	
	    String  user_id  = session.getAttribute("userID").toString();
        System.out.println(user_id);

        System.out.println("In booking.do");
        model.setViewName("book"); 
        BookingDetails book=new BookingDetails();
        model.addObject("book",book);
        //nextJsp = "/book.jsp";
    	return model;
    }
    
    @RequestMapping(value ="/checkAvailability.do",method=RequestMethod.POST)
    public ModelAndView checkAvailability(@ModelAttribute BookingDetails book,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	 HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
	 	 String  user_id  = session.getAttribute("userID").toString();
 		System.out.println(user_id);

 		model.addObject("hotelName", services.GetHotelName(book.getHotel().getHotel_id()));
 		
 		model.addObject("fromDate", book.getBooked_from());
 		model.addObject("toDate", book.getBooked_to());
 		
 		/*model.addObject("noOfRooms",no_of_rooms);*/
 		model.addObject("noOfAdults",book.getNo_of_adults());
 		model.addObject("noOfChildren",book.getNo_of_children());
 		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date datefrom = book.getBooked_from();
		Date dateto = book.getBooked_to();
		 Date sysdate = new Date();

		if (dateto.before(datefrom)) {
		    System.out.println("Date1 is before Date2");
		    model.addObject("dateError","check-in date must be before check-out Date");
		    model.setViewName("book");
		    model.addObject("book",book);
		   /* dispatch = request.getRequestDispatcher("booking.do");
			dispatch.forward(request,response);*/
		    return model;
		 
		} else
			if (datefrom.equals(dateto)) {
		    System.out.println("Date1 is equal to Date2");
		    model.addObject("dateError","check-in date must be different from check-out Date");
		    model.setViewName("book");
		    model.addObject("book",book);
		    return model;
	
		}
		else
					if (dateto.before(sysdate)||datefrom.before(sysdate)) {
				    System.out.println("Date1 is equal to Date2");
				    model.addObject("dateError","check-in /check-out date cannot be before today");
				    model.setViewName("book");
				    model.addObject("book",book);
				    return model;

		}else 
					if (dateto.after(datefrom)) {
				    System.out.println("Date1 is after Date2");
				    List<RoomDetails> rooms = services.checkAvailability(book);					 		
			 		model.addObject("RoomList", rooms);
			 		model.addObject("book",book);
			 		model.setViewName("roomDetails");
			 		return model;
				}
 	/*	
 		List<RoomDetails> rooms = services.checkAvailability(hotelID);	
 		model.addObject("RoomList", rooms);			*/				
 		//nextJsp = "/roomDetails.jsp";
		return model;
 
    }
    
    @RequestMapping("/bookHotelRoom.do")
    public ModelAndView bookHotelRoom(@RequestParam("id") String room_id,@RequestParam("rno") String room_no,@RequestParam("price") int price,@ModelAttribute BookingDetails book,HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
 		System.out.println(room_no);
 		
 		String  user_id  = session.getAttribute("userID").toString();
 		System.out.println(user_id);
 		
 		/*BookingDetails bookingDetails = new BookingDetails();*/
 		Users user=new Users();
 		user.setUser_id( session.getAttribute("userID").toString());
 		RoomDetails room=new RoomDetails();
 		room.setRoom_id(room_id);
 		book.setUser(user);
 		book.setRoom(room);
/* 		book.setNo_of_adults(Integer.parseInt(session.getAttribute("noOfAdults").toString()));
 		book.setNo_of_children(Integer.parseInt(session.getAttribute("noOfChildren").toString()));*/
/* 		
 		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDate  = LocalDate.parse(book.getBooked_from().toString());*/
		Date from = book.getBooked_from();
		Instant instant = Instant.ofEpochMilli(from.getTime());
		LocalDate fromDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
	/*	java.util.Date utilFromDate;
		try {
			utilFromDate = new SimpleDateFormat("yyyy-MM-dd").parse(fromDate.toString());
			bookingDetails.setBooked_from(utilFromDate);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
 		
 		
/*		LocalDate toDate  = LocalDate.parse(book.getBooked_to().toString());*/
		Date to = book.getBooked_from();
		Instant instant1 = Instant.ofEpochMilli(to.getTime());
		LocalDate toDate = LocalDateTime.ofInstant(instant1, ZoneId.systemDefault()).toLocalDate();
		
/*		java.util.Date utilToDate;
		try {
			utilToDate = new SimpleDateFormat("yyyy-MM-dd").parse(toDate.toString());
			bookingDetails.setBooked_to(utilToDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
		Period period = fromDate.until(toDate);
		int days  = period.getDays();
 		int amount = price*days;
 		
 		book.setAmount(amount);
 		
 		System.out.println(book);
 		
 		String bookingID = services.addbook(book);
 		
 		System.out.println(bookingID);
 		model.addObject("roomNo", room_no);
 		model.addObject("id", bookingID);
 		model.setViewName("success");
 		//nextJsp = "/success.jsp";
 		
    	return model;
    }
    
    @RequestMapping("/showRoomDetails.do")
    public ModelAndView showRoomDetails(HttpServletRequest request) throws BookingException{
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);	
    	  String UserRole = (String) session.getAttribute("UserRole");
    		
    		if(UserRole==null)
    		{
    			model.setViewName("error");
    			return model;
    		}
	 	List<RoomDetails> rooms = services.showAllRooms("1103");
	 	model.addObject("rooms", rooms);
	 	model.setViewName("roomDetails");
		//nextJsp = "/roomDetails.jsp";
    	return model;
    }
    @RequestMapping("/logout.do")
    public ModelAndView logout(HttpServletRequest request){
    	ModelAndView model=new ModelAndView();
    	HttpSession session = request.getSession(false);
    	
		session.invalidate(); //destroying session
		
		Users user=new Users();
    	model.addObject("user",user);
    	
    	Users user2=new Users();
    	model.addObject("user2",user2);
		
		model.setViewName("index");
		//nextJsp = "/index.jsp";
    	return model;
    }
    

}



/*package com.cg.appl.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

@WebServlet("*.do")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private RequestDispatcher dispatch;
    ServletContext ctx = null;
    IHotelServices services;   
    
    private String nextJsp;
    
    public HotelController() {
      services = new HotelServicesImpl();
    }

	
	public void init() throws ServletException
	{
		ctx = super.getServletContext();
		services= (IHotelServices) ctx.getAttribute("services");
		services = new HotelServicesImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (Exception e) {
			dispatch = request.getRequestDispatcher("error");
			dispatch.forward(request,response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (Exception e) {
			dispatch = request.getRequestDispatcher("error");
			dispatch.forward(request,response);
		}
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, BookingException
	{
		String command = request.getServletPath();
		System.out.println("Command : "+command);
		ctx.log("Command : "+command);
		String message;
		BookingDetails booking;
		
		switch(command)
		{
			case "/login.do":
			{//User : admin, customer
				System.out.println("ASDasdasd");
				nextJsp = "/Login.jsp";
				break;
			}//end of case for login.do
			
		case "/registerNewUser.do":
			{//User : admin, customer
				
				String userName = request.getParameter("username");
				String password = request.getParameter("password");
				String mobno = request.getParameter("mobno");
				String phno = request.getParameter("phno");
				String address = request.getParameter("address");
				String emailid = request.getParameter("emailid");
				
				Users user = new Users();
				user.setUser_name(userName);
				user.setPassword(password);
				user.setMobile_no(mobno);
				user.setPhone(phno);
				user.setAddress(address);
				user.setEmail(emailid);
				
				String uName = services.addUser(user);
				if(uName.equals(userName))
					{
						request.setAttribute("oprStatus", "User "+uName+" is Registered to system !!!");					
					}
				else
					{
						request.setAttribute("oprStatusFailed", "Unable to register New User "+uName);
					}
				
				nextJsp = "/Register.jsp";
				break;
			}//end of case for login.do		
		 case "/authenticate.do":
			{//User : admin, customer
				String userName = request.getParameter("userid");
				String pwd = request.getParameter("password");
				
				Users user = new Users();
				
				user.setUser_name(userName);
				user.setPassword(pwd);
				
				try {
					Users authenticatedUser = services.isUserAuthenticated(userName, pwd);
					if(!authenticatedUser.getUser_id().equals("error"))
					{
						System.out.println("Yes");
												
						//code for starting new session
						//Users user =  services.getUserDetails(userName);
						//getUserDetails service reqd
						HttpSession session = request.getSession(true);
						//System.out.println(session.getId());
						//model.addObject("user", user);
						String UserRole = authenticatedUser.getRole();
						if(UserRole.equals("Customer")||UserRole.equals("HotelEmp")||UserRole.equals("n/a"))
						{
							model.addObject("userID",authenticatedUser.getUser_id());
							nextJsp = "showCustomerMenu.do";
						}
						else if(UserRole.equals("Admin"))
						{
							model.addObject("userID",authenticatedUser.getUser_id());
							
							nextJsp = "showAdminMenu.do";
						}
						
					}
					else
					{
						System.out.println("No");
						
						message = "Wrong Credentials Entered !!!";
						request.setAttribute("errorMsg", message);
						ctx.log("error Message : "+message);
						nextJsp = "/index.jsp";
					}
					
				} catch (BookingException e) {
					
					dispatch = request.getRequestDispatcher("error");
					dispatch.forward(request, response);
					nextJsp = "/index.jsp";
					System.out.println(e);
					ctx.log(e.getMessage());
					message = "User Name does not exist !!!";
					request.setAttribute("errorMsg", message);
				}
				break;
			} //end of case for authenticate.do
		 case "/loadHotelDetails.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		String hotelID = request.getParameter("hotelID");
		 		
		 		Hotel hotel = services.getHotel(hotelID);
		 		
		 		model.addObject("hotel", hotel);
		 		
		 		nextJsp = "/updateHotel.jsp";
		 		break;
		 	}			
		case "/showAdminMenu.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		List<Hotel> hotelList = services.showAllHotel();
		 		model.addObject("list", hotelList);
		 		nextJsp = "/adminMenu.jsp";
		 		break;
		 	}
		case "/showAddRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("show add room user Id : "+user_id);
	 		
	 		List<Hotel> list = services.showAllHotel();
	 		model.addObject("list", list);
	 		
	 		nextJsp = "/addRoom.jsp";
	 		break;
	 	}
		case "/addRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("add room user Id : "+user_id);
	 		
	 		RoomDetails room = new RoomDetails();
	 		room.setAvailability(1);
	 		room.setHotel_id(request.getParameter("hotelName"));
	 		room.setPer_night_rate(Integer.parseInt(request.getParameter("roomPrice")));
	 		room.setRoom_no((request.getParameter("roomNo")));
	 		room.setRoom_type(request.getParameter("roomType"));
	 		
	 		String roomID = services.addRoom(room);
	 		
	 		model.addObject("oprStatus","Room: "+roomID+" is added successfully to Hotel "+services.GetHotelName(room.getHotel_id()));
	 		
	 		nextJsp = "/adminMenu.jsp";
	 		break;
	 	}
	 	
		case "/showUpdateRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("roomDetailsForUpdate user Id : "+user_id);
	 		
	 		nextJsp = "/updateRoom.jsp";
	 		break;
	 	}
		case "/showNPopulateUpdateRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("show update room user Id : "+user_id);
	 		
	 		String hotelID = request.getParameter("hotelid");
	 		String roomID = request.getParameter("roomID");
	 		
	 		model.addObject("hotelIDForUpdate", hotelID);
	 		
	 		RoomDetails room = services.showRoom(hotelID, roomID);
	 		System.out.println();
	 		if(room.getRoom_type()==null)
	 		{
	 			model.addObject("oprStatusUpdateRoom","Room id/Hotel id does not exist ");
	 			nextJsp = "/updateRoom.jsp";
	 		}
	 		else
	 		{ 
	 			model.addObject("roomDetails", room);
	 			model.addObject("roomID", roomID);
	 			model.addObject("roomIDForRoomUpdate", roomID);
	 			model.addObject("roomType",room.getRoom_type());
	 			nextJsp = "/updatePopulateRoom.jsp";
	 		}
	 		
	 		
	 		
	 		break;
	 	}
		case "/updateRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("update room user Id : "+user_id);
	 		
	 		RoomDetails room = new RoomDetails();
	 		room.setAvailability(1);
	 		room.setHotel_id(request.getParameter("hotelName"));
	 		room.setPer_night_rate(Integer.parseInt(request.getParameter("roomPrice")));
	 		room.setRoom_no((request.getParameter("roomNo")));
	 		
	 		if(request.getParameter("roomType").equals("blank"))
	 		{
	 			room.setRoom_type(request.getParameter("roomTypeOld"));
	 		}
	 		else
	 		{
	 			room.setRoom_type(request.getParameter("roomType"));
	 		}	 		
	 		
	 		System.out.println(room.getRoom_type());
	 		
	 		room.setRoom_id(session.getAttribute("roomIDForRoomUpdate").toString());
	 		
	 		boolean isUpdated = services.updateRoom(room, session.getAttribute("hotelIDForUpdate").toString());
	 		
	 		if(isUpdated)
	 		{
	 			model.addObject("oprStatus","Room: "+session.getAttribute("roomID")+" is updated successfully for Hotel "+services.GetHotelName(session.getAttribute("hotelIDForUpdate").toString()));
	 		}
	 		else
	 		{
	 			model.addObject("oprStatusFailed","Room: "+session.getAttribute("roomID")+" is Unable to update for Hotel "+services.GetHotelName(session.getAttribute("hotelIDForUpdate").toString()));
	 		}
	 		nextJsp = "/adminMenu.jsp";
	 		break;
	 	}	 	
		case "/showDeleteRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("show Delete room user Id : "+user_id);
	 		nextJsp = "/deleteRoom.jsp";
	 		break;
	 	}
		case "/deleteRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String hotelID = request.getParameter("hotelName");
	 		String roomID = request.getParameter("roomId");
	 		
	 		System.out.println("roonID " +roomID);

	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("delete room user Id : "+user_id);
	 			 		
	 		boolean isDeleted = services.deleterooms(roomID);
	 		
	 		if(isDeleted)
	 		{
	 			model.addObject("oprStatus", "Room "+roomID+"is Deleted successfully from Hotel "+services.GetHotelName(hotelID));
	 			nextJsp = "/adminMenu.jsp";
	 		}
	 		else
	 		{
	 			model.addObject("deleteException","Invalid Room ID : "+roomID);
	 			nextJsp = "/deleteRoom.jsp";
	 		}
	 		
	 		break;
	 	}	 
		case "/showAddHotel.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("user Id : "+user_id);
	 		nextJsp = "/addHotel.jsp";
	 		break;
	 	}
		 case "/addHotel.do":
			{//User : admin
				Hotel hotel = new Hotel();
				
				HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
				String hotelID = "1102";
				hotel.setHotel_id(hotelID);
				String hotelName =  request.getParameter("hotelName");
				hotel.setHotel_name(hotelName);
				String city = request.getParameter("hotelCity");
				hotel.setCity(city);
				String address = request.getParameter("address");
				hotel.setAddress(address);
				String desc = request.getParameter("desc");
				hotel.setDescription(desc);
				int price =Integer.parseInt(request.getParameter("price"));
				hotel.setAvg_rate_per_night(price);
				String contact1 = request.getParameter("phno");
				hotel.setPhone_no1(contact1);
				String contact2 = request.getParameter("phno2");
				hotel.setPhone_no2(contact2);
				int rating =Integer.parseInt(request.getParameter("rate"));
				hotel.setRating(rating);
				String email =request.getParameter("email");
				hotel.setEmail(email);
				String fax =request.getParameter("fax");
				hotel.setFax(fax);
								
				int count =services.AddHotel(hotel);
				if(count >= 1)
				{
					System.out.println("hotel added !!!");
					model.addObject("hotel", hotel);
				}
				else
				{
					message = "Unable to add new hotel !!!";
					model.addObject("errorMsg", message);
					ctx.log("error Message : "+message);
					nextJsp = "/addHotel.jsp";
				}
				
				break;
			} //end of case for authenticate.do
		 case "/showUpdateHotel.do" :
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		nextJsp = "/updateHotel.jsp";
		 		break;
		 	}
		 case "/populateUpdateHotel.do" :
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		//getting hotel id from form
		 		String hotelID = request.getParameter("hotelID");
		 		//getting hotel details from dao
		 		Hotel hotel = new Hotel();		 		
		 		
		 		hotel = services.getHotel(hotelID);
		 		
		 		if(hotel==null)
		 		{
		 			model.addObject("updateHotelIDInvalid", "Invalid Hotel ID !!!");
		 			nextJsp = "/updateHotel.jsp";
		 			dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		else
		 		{
		 			model.addObject("hotel", hotel);
		 			//setting attribute of session for populating form
			 		nextJsp="/updateHotel.jsp";
		 		}
		 		
		 		break;
		 		//nextJsp
		 	}
		 case "/updateHotel.do":
		 	{//User : admin
		 		System.out.println("In Update Hotel.do");
		 		HttpSession session = request.getSession(false);
		 		
		 		Hotel hotel = new Hotel();
		 		String hotelID = request.getParameter("hotelID2").toString();
		 		hotel.setHotel_id(hotelID);
		 		String hotelName = request.getParameter("updateHotelName").toString();
		 		hotel.setHotel_name(hotelName);
		 		String description = request.getParameter("description").toString();
		 		hotel.setDescription(description);
		 		int price = Integer.parseInt(request.getParameter("price"));
		 		hotel.setAvg_rate_per_night(price);
		 		String phno1 = request.getParameter("phno1").toString();
		 		hotel.setPhone_no1(phno1);
		 		String phno2 = request.getParameter("phno2").toString();
		 		hotel.setPhone_no2(phno2);
		 		int rating = Integer.parseInt(request.getParameter("rating"));
		 		hotel.setRating(rating);
		 		String email = request.getParameter("email").toString();
		 		hotel.setEmail(email);
		 		String fax = request.getParameter("fax").toString();
		 		hotel.setFax(fax);
		 		
		 		boolean isUpdated = services.updateHotel(hotel);
		 		System.out.println(isUpdated);
		 		if(isUpdated)
		 		{
		 			nextJsp="/adminMenu.jsp";
		 		}
		 		else
		 		{		 			
		 			nextJsp="/updateHotel.jsp";
		 			message = "Unable to update Hotel !!!";
		 			model.addObject("errorMsg", message);
		 		}
		 		break;
		 	}
		 case "/delete.do":
		 {//User : admin
			 	System.out.println("In delete.do");
			 	
			 	HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
				nextJsp = "/deleteHotel.jsp";
				break;
				//upnext command deleteHotel.do
		 }
		 case "/deleteHotel.do":
		 	{//User : admin
		 	 	 System.out.println("In deleteHotel.do");
				 String hotelId=request.getParameter("hotelId");
				 boolean flag=services.deleteHotel(hotelId);
				 if(flag)
				 {
					 System.out.println("Deleted Hotel Successfully");
					 nextJsp="/deleteHotel.jsp";
				 }
				 else
				 {
					 System.out.println("Hotel Not Deleted");
					 request.setAttribute("errorMsg","Unable To delete");
					 nextJsp="/deleteHotel.jsp";
				 }					
		 		break;
		 		//upnext command  
		 	}
		 case "/showReportsMenu.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		nextJsp = "/reportsMenu.jsp";
		 		break;
		 	}
		 case "/showHotels.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		List<Hotel> hotelList = services.showAllHotel();
		 		model.addObject("list", hotelList);
		 		
		 		nextJsp = "/HotelListReport.jsp";
		 		break;
		 	}
		 case "/getHotelIDForReport.do":
		 	{//User : admin
		 		
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		nextJsp = "/hotelIDForReport.jsp";
		 		break;
		 	}
		 case "/showHotelwiseBooking.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);		 		

		 		String hotelID= request.getParameter("hid");
		 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
		 		
		 		for(BookingDetails index : bookingList)
		 		{
		 			index.setUser(services.getUserDetailsForReport(index.getUser_id()));
		 		}
		 		if(bookingList.isEmpty())
		 		{
		 			model.addObject("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
				    
		 			nextJsp = "/acceptHotelIdForReport.jsp";
		 			dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		else
		 		{
		 			model.addObject("bookingList", bookingList);		 		
		 			nextJsp = "/BookingListReport.jsp";
			 		dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);	 			
		 		}
		 		break;
		 	}
		 case "/getHotelIDForGuestListReport.do":
		 	{//User : admin
		 		
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		nextJsp = "/acceptHotelIdForReport.jsp";
		 		break;
		 	}		 	
		 case "/showHotelwiseUsers.do":
		 	{//User : admin	

		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		String hotelID = request.getParameter("hid");
		 		
		 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
		 		
		 		for(BookingDetails index : bookingList)
		 		{
		 			index.setUser(services.getUserDetailsForReport(index.getUser_id()));
		 		}
		 		
		 		if(bookingList.isEmpty())
		 		{
		 			model.addObject("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
				    
		 			nextJsp = "/acceptHotelIdForReport.jsp";
		 			dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		else
		 		{
		 		
			 		model.addObject("bookingList", bookingList);		 		
			 		nextJsp = "/GuestListReport.jsp";
			 		dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		break;
		 	}
		 case "/getDatesForReport.do":
		 	{//User : admin
		 		
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		nextJsp = "/specifiedDateReport.jsp";
		 		break;
		 	}				 
		 case "/showDatewiseBooking.do":		
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		String hotelID= request.getParameter("hotelid");
		 		String fromDate = request.getParameter("from");
		 		String toDate = request.getParameter("to");
		 		//#####################################
		 		try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date datefrom = sdf.parse(request.getParameter("from"));
					Date dateto = sdf.parse(request.getParameter("to"));
					 Date sysdate = new Date();

					if (dateto.before(datefrom)) {
					    System.out.println("Date1 is before Date2");
					    model.addObject("dateErrorForDateReport","check-in date must be before check-out Date");
					    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);
					} else
						if (datefrom.equals(dateto)) {
					    System.out.println("Date1 is equal to Date2");
					    model.addObject("dateErrorForDateReport","check-in date must be different from check-out Date");
					    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);
					}
					else
								if (dateto.before(sysdate)||datefrom.before(sysdate)) {
							    System.out.println("Date1 is equal to Date2");
							    model.addObject("dateErrorForDateReport","check-in /check-out date cannot be before today");
							    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
								dispatch.forward(request,response);
					}else 
								if (dateto.after(datefrom)) {
							    System.out.println("Date1 is after Date2");
							    List<BookingDetails> bookingList = services.viewBookingDatewise(fromDate, toDate);	 		
						 		
							    if(bookingList.isEmpty())
							    {
							    	model.addObject("dateErrorForDateReport","Hotel ID does not exist !!!");
								    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
									dispatch.forward(request,response);
							    }else
							    {
							    
							 		model.addObject("bookingList",bookingList);
							 		
							 		nextJsp="/dateReport.jsp";
							 		
								    dispatch = request.getRequestDispatcher(nextJsp);
									dispatch.forward(request,response);
							    }
							}
					
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
		 		//#####################################
		 		
		 		break;
		 	}
		 case "/showCustomerMenu.do":
		 	{//User : customer
		 		HttpSession session = request.getSession(false);
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		List<Hotel> list = services.showAllHotel();
		 		model.addObject("list", list);
		 		
		 		System.out.println(list);
		 		
		 		nextJsp = "/book.jsp";
		 		break;
		 	}
		 case "/showBookingStatus.do""/showBookingHistory.do":
		 	{//User : customer
		 		HttpSession session = request.getSession(false);		 		
		 		
		 		break;
		 	}
		 case "/booking.do":
		 {//User : customer
			 	HttpSession session = request.getSession(false);
			 	
			 			 		String  user_id  = session.getAttribute("userID").toString();
			 		System.out.println(user_id);
				 	
			 		
				 	System.out.println("In booking.do");
					nextJsp = "/book.jsp";
			 	
				break;
			//upnext command showRoomDetails.do
		 }
		 
		 case "/checkAvailability.do":
			 {
				 HttpSession session = request.getSession(false);

				 	 String  user_id  = session.getAttribute("userID").toString();
			 		System.out.println(user_id);
				 
			 		String hotelID = request.getParameter("hotelName").toString();
			 		Hotel hotel = new Hotel();
			 		hotel.setHotel_id(hotelID);
			 		
			 		model.addObject("hotelName", services.GetHotelName(hotelID));
			 		
			 		model.addObject("fromDate", request.getParameter("from"));
			 		model.addObject("toDate", request.getParameter("to"));
			 		
			 		model.addObject("noOfRooms", request.getParameter("noOfRooms"));
			 		model.addObject("noOfAdults", request.getParameter("noOfAdults"));
			 		model.addObject("noOfChildren", request.getParameter("noOfChildren"));
			 		
			 		try {
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						Date datefrom = sdf.parse(request.getParameter("from"));
						Date dateto = sdf.parse(request.getParameter("to"));
						 Date sysdate = new Date();

						if (dateto.before(datefrom)) {
						    System.out.println("Date1 is before Date2");
						    model.addObject("dateError","check-in date must be before check-out Date");
						    dispatch = request.getRequestDispatcher("booking.do");
							dispatch.forward(request,response);
						} else
							if (datefrom.equals(dateto)) {
						    System.out.println("Date1 is equal to Date2");
						    model.addObject("dateError","check-in date must be different from check-out Date");
						    dispatch = request.getRequestDispatcher("booking.do");
							dispatch.forward(request,response);
						}
						else
									if (dateto.before(sysdate)||datefrom.before(sysdate)) {
								    System.out.println("Date1 is equal to Date2");
								    model.addObject("dateError","check-in /check-out date cannot be before today");
								    dispatch = request.getRequestDispatcher("booking.do");
									dispatch.forward(request,response);
						}else 
									if (dateto.after(datefrom)) {
								    System.out.println("Date1 is after Date2");
								    List<RoomDetails> rooms = services.checkAvailability(hotel.getHotel_id());					 		
							 		model.addObject("RoomList", rooms);
								    dispatch = request.getRequestDispatcher("/roomDetails.jsp");
									dispatch.forward(request,response);
								}
						
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
			 		
			 		List<RoomDetails> rooms = services.checkAvailability(hotel.getHotel_id());
			 		
			 		model.addObject("RoomList", rooms);
			 		nextJsp = "/roomDetails.jsp";
				 	
					break;
			 		//next jsp roomdetails.jsp
			 }
		 
		 case "/bookHotelRoom.do":
		 	{//User : customer
		 		HttpSession session = request.getSession(false);
		 		String  room_no  = request.getParameter("rno");
		 		System.out.println(room_no);
		 		
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println(user_id);
		 		
		 		BookingDetails bookingDetails = new BookingDetails();
		 		
		 		bookingDetails.setUser_id(session.getAttribute("userID").toString());
		 		bookingDetails.setRoom_id(request.getParameter("id").toString());
		 		bookingDetails.setNo_of_adults(Integer.parseInt(session.getAttribute("noOfAdults").toString()));
		 		bookingDetails.setNo_of_children(Integer.parseInt(session.getAttribute("noOfChildren").toString()));
		 		
		 		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate fromDate  = LocalDate.parse(session.getAttribute("fromDate").toString(),formatter);
				java.util.Date utilFromDate;
				try {
					utilFromDate = new SimpleDateFormat("yyyy-MM-dd").parse(fromDate.toString());
					bookingDetails.setBooked_from(utilFromDate);
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		 		
		 		
				LocalDate toDate  = LocalDate.parse(session.getAttribute("toDate").toString(),formatter);
				java.util.Date utilToDate;
				try {
					utilToDate = new SimpleDateFormat("yyyy-MM-dd").parse(toDate.toString());
					bookingDetails.setBooked_to(utilToDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				Period period = fromDate.until(toDate);
				int days  = period.getDays();
		 		int amount = (Integer.parseInt(request.getParameter("price"))*days);
		 		
		 		bookingDetails.setAmount(amount);
		 		
		 		System.out.println(bookingDetails);
		 		
		 		String bookingID = services.addbook(bookingDetails);
		 		
		 		System.out.println(bookingID);
		 		model.addObject("roomNo", room_no);
		 		model.addObject("id", bookingID);
		 		nextJsp = "/success.jsp";
		 		
		 		break;
				//upnext command confirmBooking.do
		 	}
		 case "/showRoomDetails.do":
		 {//User : customer
			 	HttpSession session = request.getSession(false);	
			 	List<RoomDetails> rooms = services.showAllRooms("1103");
			 	model.addObject("rooms", rooms);
				nextJsp = "/roomDetails.jsp";
				break;
			//upnext command bookHotelRoom.do
		 }
		 case "/logout.do":
			{
				HttpSession session = request.getSession(false);
				session.invalidate(); //destroying session
				
				nextJsp = "/index.jsp";
				break;
			}//end of case for logout.do
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
	}
	public void destroy() {
		services = null;
		dispatch = null;
	}
}
*/