package com.cg.appl.exception;

public class BookingException extends Exception{

	private static final long serialVersionUID = 1L;
	public BookingException() {
		super();
	}
	public BookingException(String msg) {
		super(msg);
	}
	public BookingException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}
	public BookingException(String message, Throwable cause) {
		super(message, cause);
		
	}
	public BookingException(Throwable cause) {
		super(cause);
		
	}

}
