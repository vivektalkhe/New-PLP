DROP TABLE Booking_Details;
DROP TABLE Room_Details;
DROP TABLE Users;
DROP TABLE Hotel;

DROP SEQUENCE seq_booking_Id;
DROP SEQUENCE seq_hotel_Id;
DROP SEQUENCE room_id_seq;
DROP SEQUENCE user_id_seq;

Create Table Users
(
	user_id varchar2(4),
	password varchar2(10),
	role varchar2(10),
	user_name varchar2(20),
	mobile_no varchar2(10),
	phone varchar2(10),
	address varchar2(25),
	email varchar2(25),
	CONSTRAINT user_id_PK PRIMARY KEY (user_id)
);

Create Table Hotel
(
hotel_id varchar2(4),
city varchar2(10),
hotel_name varchar2(10),
address varchar2(25),
description varchar2(200),
avg_rate_per_night number(10,2),
phone_no1 varchar2(10),
phone_no2 varchar2(10),
rating number(2),
email varchar2(25),
fax varchar2(15),
CONSTRAINT hotel_id_PK PRIMARY KEY (hotel_id)
);


CREATE TABLE Room_Details
(
hotel_id varchar2(4),
room_id varchar2(4),
room_no varchar2(3),
room_type varchar2(40),
per_night_rate number(6,2),
availability number,
--1 for available and 0 for not available
photo varchar2(40),
CONSTRAINT room_id_PK PRIMARY KEY (room_id),
CONSTRAINT chk_room_type
	CHECK (room_type IN ('Standard non A/C room','Standard A/C room','Executive A/C room','Deluxe A/C room')),
CONSTRAINT hotel_id_FK
	FOREIGN KEY (hotel_id)
	REFERENCES Hotel(hotel_id)
	ON DELETE SET NULL
);


CREATE TABLE Booking_Details
(
booking_id varchar2(4),
hotel_id varchar2(4) ,
room_id varchar2(4),
user_id varchar2(4),
booked_from date,
booked_to date,
no_of_adults number(2),
no_of_children number(2),
amount number(10,2),
CONSTRAINT booking_id_PK PRIMARY KEY (booking_id),
CONSTRAINT user_id_FK
	FOREIGN KEY (user_id)
	REFERENCES Users(user_id),	
CONSTRAINT hotel_id_FK1
	FOREIGN KEY (hotel_id)
	REFERENCES Hotel(hotel_id),	
CONSTRAINT room_id_FK
	FOREIGN KEY (room_id)
	REFERENCES Room_Details(room_id)
);

CREATE SEQUENCE seq_booking_Id
  MINVALUE 8000
  MAXVALUE 9999
  START WITH 8004
  INCREMENT BY 1
  CACHE 5;
  
  
  CREATE SEQUENCE seq_hotel_Id
  MINVALUE 5000
  MAXVALUE 7999
  START WITH 5004
  INCREMENT BY 1
  CACHE 5;
  
  CREATE SEQUENCE room_id_seq
  MINVALUE 3000
  MAXVALUE 4999
  START WITH 3013
  INCREMENT BY 1
  CACHE 5;
  
  CREATE SEQUENCE user_id_seq
  MINVALUE 1000
  MAXVALUE 2999
  START WITH 1006
  INCREMENT BY 1
  CACHE 5;
  
  
  INSERT INTO Users VALUES ('1001','admin123','Admin','Scott','9638527410','235689','street no 5, Mumbai','scott@abc.com');
INSERT INTO Users VALUES ('1002','cust123','Customer','King','9966338451','223355','street no 11, Banglore','king@gmail.com');
INSERT INTO Users VALUES ('1003','hotel123','HotelEmp','Smith','8956230174','568921','street no 2, Mumbai','smith@abc.com');
INSERT INTO Users VALUES ('1004','a','Admin','a','9562843213','568921','Mumbai','a@abc.com');
INSERT INTO Users VALUES ('1005','c','Customer','c','9562899999','568921','Mumbai','c@abc.com');
  


INSERT INTO hotel VALUES ('5001','Pune','Trident','Nariman, Pune','Nestled in the heart of vibrant and bustling Mumbai lies our hotel Trident, Nariman Point.',5000.00,'888888','898989',5,'contactus@Trident.com','+912266325000');
INSERT INTO hotel VALUES ('5002','Pune','Oberoi','Marine Drive, Pune','Nestled in beautiful city',4000.00,'999999','797979',3,'contactus@Oberoi.com','+912266645880');
INSERT INTO hotel VALUES ('5003','Pune','Sagar','Colaba, Pune','Service at its best',3500.00,'777777','757575',4,'contactus@Sagar.com','+912299995000');



INSERT INTO Room_Details VALUES ('5001','3001','FA1','Standard non A/C room',3000.00,1,'');
INSERT INTO Room_Details VALUES ('5001','3002','FA2','Standard A/C room',4500.00,1,'');
INSERT INTO Room_Details VALUES ('5001','3003','FB1','Executive A/C room',5000.00,1,'');
INSERT INTO Room_Details VALUES ('5001','3004','FB2','Deluxe A/C room',6000.00,1,'');


INSERT INTO Room_Details VALUES ('5002','3005','FA1','Standard non A/C room',3000.00,1,'');
INSERT INTO Room_Details VALUES ('5002','3006','FA2','Standard A/C room',4500.00,1,'');
INSERT INTO Room_Details VALUES ('5002','3007','FB1','Executive A/C room',5000.00,1,'');
INSERT INTO Room_Details VALUES ('5002','3008','FB2','Deluxe A/C room',6000.00,1,'');

INSERT INTO Room_Details VALUES ('5003','3009','FA1','Standard non A/C room',3000.00,1,'');
INSERT INTO Room_Details VALUES ('5003','3010','FA2','Standard A/C room',4500.00,1,'');
INSERT INTO Room_Details VALUES ('5003','3011','FB1','Executive A/C room',5000.00,1,'');
INSERT INTO Room_Details VALUES ('5003','3012','FB2','Deluxe A/C room',6000.00,1,'');

INSERT INTO Booking_Details VALUES('8001','5001','3001','1001','12-MAY-2016','21-MAY-2016',2,1,27000.00);
INSERT INTO Booking_Details VALUES('8002','5001','3002','1002','19-FEB-2017','21-FEB-2017',2,1,10500.00);
INSERT INTO Booking_Details VALUES('8003','5002','3003','1003','15-JAN-2017','21-JAN-2017',2,1,30000.00);

commit
